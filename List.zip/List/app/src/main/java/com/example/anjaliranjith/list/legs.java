package com.example.anjaliranjith.list;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class legs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legs);
    }

    public void result1 (View view){
        String desc ="ABNORMAL WALKING(GAINT)\n" +
                "----------------------\n" +
                "Walking abnormalities are unusual and uncontrollable walking patterns. They are usually due to diseases or injuries to the legs, feet, brain, spinal cord, or inner ear.\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "General causes of abnormal gait may include:\n" +
                "\n" +
                "1.Arthritis of the leg or foot joints\n" +
                "2.Conversion disorder (a psychological disorder)\n" +
                "3.Foot problems (such as a callus, corn, ingrown toenail, wart, pain, skin sore, swelling, or spasms)\n" +
                "4.Fracture\n" +
                "5.Injections into muscles that causes soreness in the leg or buttocks\n" +
                "6.Infection\n" +
                "7.Injury\n" +
                "8.Legs that are of different lengths\n" +
                "9.Myositis\n" +
                "10.Shin splints\n" +
                "11.Shoe problems\n" +
                "12.Tendonitis\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Treating the cause often improves the gait. For example, gait abnormalities from trauma to part of the leg will improve as the leg heals.\n" +
                "\n" +
                "Physical therapy almost always helps with short-term or long-term gait disorders. Therapy will reduce the risk of falls and other injuries.\n" +
                "\n" +
                "For an abnormal gait that occurs with conversion disorder, counseling and support from family members are strongly recommended.\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","Gaint");
        res.putExtra("Gaint", desc);
        startActivity(res);
    }
    public void result2 (View view){
    String desc ="BULGING VEINS IN THE LEGS\n" +
            "-------------------------\n" +
            "\n" +
            "Causes:\n" +
            "\n" +
            "Aching pain that may get worse after sitting or standing for a long time.\n" +
            "Darkening of the skin\n" +
            "Feeling of heaviness in legs\n" +
            "Rash that is itchy or irritated\n" +
            "Swelling\n" +
            "Throbbing or cramping\n" +
            "\n" +
            "Treatment:\n" +
            "\n" +
            "Self-help\n" +
            "Non-surgical treatments\n" +
            "Compression stockings";
    Intent res =new Intent(this,result.class);
    res.putExtra("key","bulgingvein");
    res.putExtra("bulgingvein", desc);
    startActivity(res);
}
    public void result3 (View view){
        String desc ="ENLARGED (DILATED) VEINS\n" +
                "------------------------\n" +
                "\n" +
                "There is 1 condition associated with enlarged (dilated) veins.\n" +
                "\n" +
                "Thrombophlebitis\n" +
                "Blood clots in the leg can become very dangerous; symptoms include swelling, redness, and leg tenderness.\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","enlarged");
        res.putExtra("enlarged", desc);
        startActivity(res);
    }
    public void result4 (View view){
        String desc ="JOINT PAINS IN LEGS\n" +
                "-------------------\n" +
                "\n" +
                "Joints form the connections between bones. They provide support and help you move. Any damage to the joints from disease or injury can interfere with your movement and cause a lot of pain.\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "1.Protect the joint with a brace or wrap.\n" +
                "2Rest the joint, avoiding any activities that cause you pain.\n" +
                "3.Ice the joint for about 15 minutes, several times each day.\n" +
                "4.Compress the joint using an elastic wrap.\n" +
                "5.Elevate the joint above the level of your heart.\n" +
                "\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","jointpain");
        res.putExtra("jointpain", desc);
        startActivity(res);
    }
    public void result5 (View view){
        String desc ="MUSCLE TWITCHING (PAINLESS) IN LEGS\n" +
                "------------------------------------\n" +
                "\n" +
                "Muscle twitching, also known as muscle fasciculation, is marked by small muscle contractions in the body.\n" +
                " Your muscles are composed of fibers, tissues, and nerves. \n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "No treatment is usually needed for benign muscle twitching.\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","twitching");
        res.putExtra("twitching", desc);
        startActivity(res);
    }
    public void result6 (View view){
        String desc ="RESTLESS(URGE TO MOVE LEGS)\n" +
                "---------------------------\n" +
                "\n" +
                "Restless legs syndrome (RLS) is a neurological disorder characterized by throbbing, pulling, creeping, or other unpleasant sensations in the legs and an uncontrollable, and sometimes overwhelming, urge to move them\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Chronic diseases such as kidney failure, diabetes, and peripheral neuropathy. Treating the underlying condition often provides relief from RLS symptoms.\n" +
                "Certain medications that may aggravate symptoms. These medications include antinausea drugs (prochlorperazine or metoclopramide), antipsychotic drugs (haloperidol or phenothiazine derivatives), antidepressants that increase serotonin, and some cold and allergy medications-that contain sedating antihistamines.\n" +
                "Pregnancy, especially in the last trimester. In most cases, symptoms usually disappear within 4 weeks after delivery.\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "1.Blood testing to reveal underlying iron deficiency anemia may reveal the underlying cause.\n" +
                "2.If varicose veins are thought to be the cause, then surgery to repair the circulation may be considered.\n" +
                "3.Reduction or elimination of caffeine, nicotine, and alcohol from a person's diet can be very helpful.\n" +
                "4.Stopping smoking can significantly diminish or prevent symptoms.\n" +
                "5.Getting better sleep and exercise can help some persons affected by restless legs.\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","restless");
        res.putExtra("restless", desc);
        startActivity(res);
    }
    public void result7 (View view){
        String desc ="SHORTNING OF LIMBS \n" +
                "-------------------\n" +
                "\n" +
                "Unequal leg length (also termed leg length inequality, LLI or leg length discrepancy, LLD) is where the legs are either different lengths or appear to be different lengths because of misalignment.\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "The most common treatment for discrepancies in leg length is the use of a simple heel lift, which can be placed within the shoe. In cases where the length discrepancy is moderate, an external build up to the shoe is usually more comfortable. In severe cases, surgery can be used to make the longer leg shorter (or impede its growth), and/or make the shorter leg longer.\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","limbs");
        res.putExtra("limbs", desc);
        startActivity(res);
    }
    public void result8 (View view){
        String desc ="TWISTING OR ROTATION OF LIMBS\n" +
                "------------------------------\n" +
                "\n" +
                "There is 1 condition associated with twisting or rotation of limb. \n" +
                "\n" +
                "Broken (fractured) hip\n" +
                "     A broken hip is a break in the thighbone under the hip joint and causes pain and trouble or inability to walk\n" +
                "\n";
        Intent res =new Intent(this,result.class);
        res.putExtra("key","rotation");
        res.putExtra("rotation", desc);
        startActivity(res);
    }

}