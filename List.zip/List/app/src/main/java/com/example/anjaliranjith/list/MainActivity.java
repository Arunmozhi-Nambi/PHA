package com.example.anjaliranjith.list;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void result1(View view) {
        String desc = "BLOATING OR FULLNESS IN ABDOMEN \n" +
                "---------------------------\n" +
                "\n" +
                "Abdominal bloating is a condition in which the abdomen feels uncomfortably full and gaseous, and may also be visibly swollen (distended). \n" +
                "Causes:\n" +
                "\n" +
                "1.Indigestion\n" +
                "2.Gas & Flatulence\n" +
                "3.Lactose Intolerance\n" +
                "4.Gallstones\n" +
                "5.H.Pylori Infection\n" +
                "6.Giardiasis\n" +
                "7.Irritable Bowel Syndrome\n" +
                "8.Fatty Liver.\n" +
                "9.Ovarian Cancer\n" +
                "\n" +
                "Precautions:\n" +
                "\n" +
                "•Avoid carbonated beverages.\n" +
                "•Avoid chewing gum as this predisposes to air swallowing.\n" +
                "•Avoid foods that are difficult to digest or that cause increased amounts of gas (e.g. brussel sprouts, cabbage, beans and lentils).\n" +
                "•Be careful of your sources of fibre. Patients with IBS often need increased amounts of fibre to relieve their symptoms, however, some types of fibre such as psyllium   (in Metamucil) can exacerbate bloating. You should discuss your choice of fibre supplements with a pharmacist.\n" +
                "•Eat small, frequent meals at a reasonable pace (slowly).\n" +
                "•Drinking fennel tea may help your symptoms.";


        Intent res = new Intent(this, result.class);
        res.putExtra("key", "Bloating");
        res.putExtra("Bloating", desc);
        startActivity(res);
    }

    public void result2(View view) {
        String desc = "BLOODY OR RED VOMIT \n" +
                "--------------------\n" +
                "\n" +
                "Vomiting blood is regurgitating (throwing up) contents of the stomach that contains blood.\n" +
                "\n" +
                "Vomited blood may appear either a bright red or dark red color. The vomited material may be mixed with food or it may be blood only.\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "•Bleeding ulcer in the stomach, first part of the small intestine, or esophagus\n" +
                "•Blood clotting disorders\n" +
                "•Defects in the blood vessels of the GI tract\n" +
                "•Swelling, irritation, or inflammation of the esophagus lining (esophagitis) or the stomach lining (gastritis)\n" +
                "•Swallowing blood (for example, after a nosebleed)\n" +
                "•Tumors of the mouth, throat, stomach or esophagus.\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Get medical attention right away. Vomiting blood can be a result of a serious medical problem.\n"

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "BloodyVomit");
        res.putExtra("BloodyVomit", desc);
        startActivity(res);

    }

    public void result3(View view) {
        String desc = "BULGING VEINS \n" +
                "---------------\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Blood vessel disorders \n" +
                "Abdominal swelling \n" +
                "Abdominal distention \n" +
                "Caput medusae \n" +
                "Acute pancreatitis \n" +
                "Cirrhosis of the liver \n" +
                "Ovarian cyst \n" +
                "Kidney tumor \n" +
                "Kidney cancer \n" +
                "Ascites \n" +
                "Malignant ascites\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Consult a doctor as soon as possible.\n" +
                "\n";


        Intent res = new Intent(this, result.class);
        res.putExtra("key", "BulgingVeins");
        res.putExtra("BulgingVeins", desc);
        startActivity(res);

    }

    public void result4(View view) {
        String desc = "CHANGE IN BOWEL HABITS\n" +
                "----------------------\n" +
                "Bowel habits can vary from person to person .This includes how often a bowel movemet,your control over when you havea bowel movement ,and the bowel movement's cosistncy and color .\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Changes in bowel habits can be caused by a range of conditions, from a temporary infection to an underlying medical disorder. Examples of chronic conditions that can cause changes in bowel habits include: \n" +
                "•celiac disease\n" +
                "•Crohn’s disease\n" +
                "•diverticulosis\n" +
                "•hyperthyroidism\n" +
                "•irritable bowel syndrome (IBS)\n" +
                "•ulcerative colitis\n" +
                "\n" +
                "Treatment :\n" +
                "\n" +
                "Seek immediate medical attention if you experience the following changes in bowel habits: \n" +
                "•blood in your stool\n" +
                "•mucus in your stool\n" +
                "•passing watery, diarrhea-like stools for more than 24 hours \n" +
                "•pus in your stool \n" +
                "•severe abdominal pain\n" +
                "\n" +
                "Make an appointment to see your doctor if you experience the following: \n" +
                "•have not passed stool in three days \n" +
                "•inability to pass gas\n" +
                "•mild abdominal pain \n" +
                "•sudden urges to have a bowel movement with an inability to control the bowel movement \n" +
                "•unexplained weight loss \n" +
                "•very narrow stool ";


        Intent res = new Intent(this, result.class);
        res.putExtra("key", "bowel");
        res.putExtra("bowel", desc);
        startActivity(res);

    }

    public void result5(View view) {
        String desc = "COFFEE GROUND VOMITS\n" +
                "---------------------\n" +
                "\n" +
                "The term coffee ground vomitus describes vomit that looks like coffee grounds. This is a result of coagulated blood in the vomit. Vomiting blood is also known as hematemesis or coffee ground emesis. \n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "1.liver disease \n" +
                "2.cancer of esophagus,pancreas or stomach\n" +
                "3.peptic or stomach ulcers\n" +
                "4.bleeding esophageal varices\n" +
                "5.gastritis or inflammation to the stomach\n" +
                "6.gastroesphageal reflux disease\n" +
                "7.aspirin overdose\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Examination by the doctor is necessary."

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "coffe");
        res.putExtra("coffe", desc);
        startActivity(res);

    }

    public void result6(View view) {
        String desc = "CONSTIPATION\n" +
                "-------------\n" +
                "Constipation (also known as costiveness or dyschezia) refers to bowel movements that are infrequent or hard to pass. Constipation is a common cause of painful defecation. Severe constipation includes obstipation (failure to pass stools or gas) and fecal impaction, which can progress to bowel obstruction and become life-threatening.\n" +
                "\n" +
                "Causes:\n" +
                "1.Dairy products\n" +
                "2.Foods high in fat and sugar\n" +
                "3.Lack of high-fiber foods (like fruits, vegetables, and whole grains)\n" +
                "4.Lack of water and other fluids\n" +
                "5.Alcohol or caffeine\n" +
                "\n" +
                "Treatments:\n" +
                "\n" +
                "1.Eat more fiber.\n" +
                "2.Drink Liquids.\n" +
                "3.Exercise Reularly\n" +
                "4.Cnsider laxatives.";

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "constipation");
        res.putExtra("constipation", desc);
        startActivity(res);

    }

    public void result7(View view) {
        String desc = "DRAINAGE OR PUSS \n" +
                "--------------\n" +
                "\n" +
                "An abdominal abscess is a pocket of pus located in the abdomen. It may form:\n" +
                "\n" +
                "behind the abdominal cavity (which contains most of the digestive organs)\n" +
                "below the diaphragm (the muscle used during inhalation)\n" +
                "within the abdominal compartment \n" +
                "\n" +
                "Caues:\n" +
                "feeling unwell\n" +
                "abdominal discomfort\n" +
                "abdominal pain\n" +
                "If an infection is present, you may also develop:\n" +
                "\n" +
                "fever\n" +
                "nausea\n" +
                "weight loss (due to loss of appetite)\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Consulting a doctor.";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "pus");
        res.putExtra("pus", desc);
        startActivity(res);

    }

    public void result8(View view) {
        String desc = "FREQUENT URGE TO HAVE BOWEL MOVEMENT \n" +
                "------------------------------------\n" +
                "Causes:\n" +
                "\n" +
                "f you're having bowel movements more often than usual, chances are you've made some change in your lifestyle. You may, for example, be:\n" +
                "\n" +
                "Eating more fruits, vegetables and whole grains, which increases fiber intake\n" +
                "Getting regular exercise or increasing your exercise\n" +
                "Drinking more water.\n" +
                "\n" +
                "Suggestions:\n" +
                "\n" +
                "See your doctor if more-frequent bowel movements are also accompanied by any of the following signs or symptoms:\n" +
                "\n" +
                "1.Changes in the consistency, volume or appearance of    your bowel movements, such as repeatedly passing    narrow, ribbon-like stools or loose, watery stools\n" +
                "2.Abdominal pain\n" +
                "3.Blood, mucus or pus in your feces.\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "urge");
        res.putExtra("urge", desc);
        startActivity(res);

    }

    public void result9(View view) {
        String desc = "LUMP OR BULDGE IN ABDOMAIN \n" +
                "---------------------------\n" +
                "\n" +
                "An abdominal lump is a swelling or bulge that emerges from any area of the abdomen. It most often feels soft, but it may be firm depending on its underlying cause.\n" +
                "\n" +
                "Causes:\n" +
                "1.Inguinal Hernia\n" +
                "2.Umbilical Hernia\n" +
                "3.Hematoma\n" +
                "4.Lipoma\n" +
                "5.Undescended Testicle\n" +
                "6.Tumor\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "If you feel or see a lump in your abdomen that you cannot identify, make an appointment to see your doctor. If you also have a fever, vomiting, or pain around the lump, you may need emergency care.\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "LUMP");
        res.putExtra("LUMP", desc);
        startActivity(res);

    }


    public void result10(View view) {
        String desc = "MUSCLE CRAMPS OR SPASM \n" +
                "-----------------------\n" +
                "\n" +
                "Abdominal muscle spasm, also known as abdominal rigidity, is a powerful, involuntary contraction of the muscles of the abdomen.\n" +
                "\n" +
                "Symptoms:\n" +
                "\n" +
                "Abdominal pain\n" +
                "Abdominal swelling, distension or bloating\n" +
                "Belching\n" +
                "Change in bowel habits\n" +
                "Constipation\n" +
                "Diarrhea\n" +
                "Discolored stools\n" +
                "Heartburn\n" +
                "Nausea with or without vomiting\n" +
                "Pulsating mass in the abdomen\n" +
                "Rectal bleeding or blood in the stool\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "spasm");
        res.putExtra("spasm", desc);
        startActivity(res);

    }

    public void result11(View view) {
        String desc = "NAUSEA or VOMITTING\n" +
                "---------------------\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "motion sickness\n" +
                "emotional stress\n" +
                "indigestion\n" +
                "food poisoning\n" +
                "viruses\n" +
                "exposure to chemical toxins\n" +
                "\n" +
                "Treatments:\n" +
                "\n" +
                "To treat nausea at home:\n" +
                "\n" +
                "1.Consume only light, plain foods, such as bread and crackers.\n" +
                "2.Avoid any foods that have strong flavors, are very sweet, or are greasy or fried.\n" +
                "3.Drink cold liquids.\n" +
                "4.Avoid any activity after eating.\n" +
                "5.Drink a cup of ginger tea.\n" +
                "6.Eat smaller, more frequent meals.\n" +
                "\n" +
                "Self-Treatment for Vomiting:\n" +
                "1.Drink a large amount of clear fluids to remain   hydrated.\n" +
                "2.Avoid solid foods of any kind until vomiting stops.\n" +
                "3.Rest.\n" +
                "4.Avoid using medications that may upset your stomach,   such as nonsteroidal anti-inflammatory drugs,    corticosteroids, and blood thinners (but clear this   with your doctor first).\n" +
                "5.Use an oral rehydrating solution to replace lost    electrolytes.\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "vomitting");
        res.putExtra("vomitting", desc);
        startActivity(res);

    }

    public void result12(View view) {
        String desc = "NUMBNESS OR TINGLING \n" +
                "---------------------\n" +
                "\n" +
                "Numbness is a decreased or lost sensation in the skin. Tingling is an unusual sensation in the skin. It is often described as feeling of pins and needles, tickling, pricking, creeping, skin crawling, ant crawling, and so on.\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Stress\n" +
                "Anxiety\n" +
                "Irritable bowel syndrome\n" +
                "Nervousness\n" +
                "Reaction to medications\n" +
                "Menopause\n" +
                "\n" +
                "Treatment :\n" +
                "\n" +
                "Only your doctor can advise whether any of these treatments are appropriate for your specific medical situation. Always discuss all treatment options with your doctor before making a decision, including whether to start or discontinue any treatment plan.";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "tingling");
        res.putExtra("tingling", desc);
        startActivity(res);

    }

    public void result13(View view) {
        String desc = "PAIN OR DISCOMFORT IN ABDOMEN\n" +
                "------------------------------\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Less serious causes of abdominal pain include:\n" +
                "\n" +
                "Constipation\n" +
                "Irritable bowel syndrome\n" +
                "Food allergies or intolerance (such as lactose intolerance)\n" +
                "Food poisoning\n" +
                "Stomach flu\n" +
                "Other possible causes include:\n" +
                "\n" +
                "Appendicitis\n" +
                "1.Abdominal aortic aneurysm (bulging and weakening of    the major artery in the body)\n" +
                "2.Bowel blockage or obstruction\n" +
                "3.Cancer of the stomach, colon (large bowel), and    other organs\n" +
                "4.Cholecystitis (inflammation of the gallbladder) with    or without gallstones\n" +
                "5.Decreased blood supply to the intestines (ischemic    bowel)\n" +
                "6.Diverticulitis (inflammation and infection of the   colon)\n" +
                "7.Heartburn, indigestion, or gastroesophageal reflux   (GERD)\n" +
                "8.Inflammatory bowel disease (Crohn's disease or    ulcerative colitis)\n" +
                "9.Kidney stones\n" +
                "10.Pancreatitis (swelling or infection of the     pancreas)\n" +
                "11.Ulcers\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "hese additional steps may help prevent some types of abdominal pain:\n" +
                "\n" +
                "1.Drink plenty of water each day.\n" +
                "2.Eat small meals more frequently.\n" +
                "3.Exercise regularly.\n" +
                "4.Limit foods that produce gas.\n" +
                "5.Make sure that your meals are well-balanced and high     in fiber. Eat plenty of fruits and vegetables.\n" +
                "\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "PAIN");
        res.putExtra("PAIN", desc);
        startActivity(res);

    }


    public void result15(View view) {
        String desc = "STOMACH UPSET\n" +
                "------------\n" +
                "\n" +
                "Symptoms:\n" +
                "\n" +
                "The symptoms of an upset stomach include occasional heartburn, a taste of bile in the mouth and pains in the stomach, which can be made worse by coffee, citrus fruits, fatty foods, onions, alcohol and chocolate.\n" +
                "\n" +
                "In some cases, milk can ease the pains. Other symptoms include irregular bowel movements, constipation and pain when going to the toilet.\n" +
                "\n" +
                "Suggestions:\n" +
                "\n" +
                "1.Carrot and Mint \"Juice\" Helps an Upset Stomach.\n" +
                "2.Rice Tea Alleviates an Upset Stomach.\n" +
                "3.Apple Cider Vinegar Soothes an Upset Stomach\n" +
                "4.Burnt Toast Settles an Upset Stomach\n" +
                "5.CRAP Diet Is Good for an Upset Stomach\n" +
                "6.Yogurt Reduces Discomfort from an Upset Stomach\n" +
                "7.Caraway Seeds Ease an Upset Stomach\n" +
                "8.Fennel Makes an Upset Stomach Feel Better\n" +
                "9.Heat Helps an Upset Stomach";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "UPSET");
        res.putExtra("UPSET", desc);
        startActivity(res);

    }
}