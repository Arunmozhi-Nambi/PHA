package com.example.anjaliranjith.list;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class pelvic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pelvic);
    }

    public void result1(View view) {
        String desc = "PELVIC BLEEDING\n" +
                "---------------\n" +
                "\n" +
                "Vaginal bleeding which is also know as pelvic bleeding is any bleeding through the vagina, including bleeding from the vaginal wall itself, as well as (and more commonly) bleeding from another location of the female reproductive system. Generally, it is either a physiologic response during the non-conceptional menstrual cycle or caused by hormonal or organic problems of the reproductive system.\n" +
                "Causes:\n" +
                "\n" +
                "   a growth in the uterus or cervix\n" +
                "    stress\n" +
                "   a change in medication\n" +
                "   a miscarriage\n" +
                "   vaginal dryness\n" +
                "   a hormone imbalance\n" +
                "   cancer\n" +
                "Treatment:\n" +
                "\n" +
                "1.Maintain a healthy weight. \n" +
                "2.If you are using birth control pills, be sure to take them as directed and at the same time every day.\n" +
                "3.If you are taking hormone therapy, take your pills as directed and at the same time every month.\n" +
                "4.Learn to practice relaxation exercises to reduce and cope with stress. Stress may cause abnormal vaginal bleeding. \n";

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "bleeding");
        res.putExtra("bleeding", desc);
        startActivity(res);
    }

    public void result2(View view) {
        String desc = "BLOATING OR FULNESS IN PELVIC \n" +
                "----------------------------\n" +
                " \n" +
                "There are 17 conditions associated with bloating or fullness (abdomen (lower)), bloating or fullness (pelvis), pressure or fullness or vaginal bleeding between periods including gas problems.\n" +
                "\n" +
                "    1.Gas pain\n" +
                "    2.Irritable bowel syndrome\n" +
                "    3.Urinary tract infection (UTI)\n" +
                "    4.Gastroenteritis\n" +
                "    5.Endometrial cancer\n" +
                "    6.Gallstones\n" +
                "    7.Interstitial cystitis\n" +
                "    8.Vaginitis\n" +
                "    9.Giardiasis\n" +
                "    10.Helicobacter pylori infection\n" +
                "    11.Cervicitis\n" +
                "    12.Uterine fibroids\n" +
                "    13.Foreign object in the vagina\n" +
                "    14.Uterine cancer\n" +
                "    15.Bladder stones\n" +
                "         \n" +
                "          \n" +
                "\n" +
                " Suggestions\n" +
                "\n" +
                "1.Avoid skipping meals or leaving large gaps between meals\n" +
                "2.Drink lots of water during the day\n" +
                "3.Eat small meals and chew properly\n" +
                "4.Do not talk while eating as this increases air being swallowed into the stomach\n" +
                "5.Limit food products that contain wheat and milk\n" +
                "6.Antibiotics used to treat other ailments could also lead to bloating so try and avoid too much of them\n" +
                "7.Avoid heavy meals at night and try not to lie down soon after eating";

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "fulness");
        res.putExtra("fulness", desc);
        startActivity(res);
    }

    public void result3(View view) {
        String desc = "CLOUDY URINE WITH ODOR\n" +
                "----------------------\n" +
                "\n" +
                "There are 2 conditions associated with cloudy urine with strong odo\n" +
                "\n" +
                "Urinary tract infection (UTI)\n" +
                "Urinary tract infection symptoms include pain during urination, an intense urge to urinate, and more.\n" +
                "Kidney infection (pyelonephritis)\n" +
                "Kidney infection, caused by bacteria, is marked by sudden chills and fever, pain, nausea and urinary issues.\n" +
                "\n" +
                "Treatment :\n" +
                "\n" +
                "consult a doctor.\n" +
                "Drink plenty of water.";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "odor");
        res.putExtra("odor", desc);
        startActivity(res);
    }


    public void result4(View view) {
        String desc = "DARK COLOR (BROWN) URINE \n" +
                "------------------------\n" +
                "\n" +
                "Normal urine color varies, depending on how much water you drink. Fluids dilute the yellow pigments in urine, so the more you drink, the clearer your urine looks. When you drink less, the color becomes more concentrated. Severe dehydration can produce urine the color of amber.\n" +
                "\n" +
                "But sometimes urine can turn colors far beyond what's normal, including red, blue, green, dark brown and cloudy white.\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Seek medical attention if you have:\n" +
                "\n" +
                "Visible blood in your urine. Bloody urine is common in urinary tract infections and kidney stones. Both of these problems usually cause pain. Painless bleeding may signal a more serious problem, such as cancer.\n" +
                "\n" +
                "Dark or orange urine. If your urine is dark or orange — particularly if you also have pale stools and yellow skin and eyes — your liver might be malfunctioning.";

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "dark");
        res.putExtra("dark", desc);
        startActivity(res);
    }


    public void result5(View view) {
        String desc = "DRAINAGE OR PUSS\n" +
                "----------------\n" +
                "There are 9 conditions associated with drainage or puss.\n" +
                "\n" +
                "1.Abscess\n" +
                "2.Allergic reaction\n" +
                "3.Hives\n" +
                "4.Erythema nodosum\n" +
                "5.Folliculitis\n" +
                "6.Chickenpox (varicella)\n" +
                "7.Boil\n" +
                "8.Pustular psoriasis\n" +
                "9.Basal cell skin cancer\n" +
                "   \n" +
                "Treatment:\n" +
                "\n" +
                "If the abscess is small (less than 1 cm or less than ½ inch across), applying warm compresses to the area for about 30 minutes, four times daily may help.\n" +
                "\n" +
                "Once the boil drains, it should heal on its own, though this may take several weeks.\n" +
                "\n" +
                "Do not attempt to drain the abscess by pressing on it. This can push the infected material into the deeper tissues.\n" +
                "\n" +
                "Do not stick a needle or other sharp instrument into the abscess because it may injure an underlying blood vessel or cause the infection to spread.\n";

        Intent res = new Intent(this, result.class);
        res.putExtra("key", "drainage");
        res.putExtra("drainage", desc);
        startActivity(res);
    }


    public void result6(View view) {
        String desc = "DIFFICULTY IN CLIMBING STAIRS \n" +
                "-----------------------------\n" +
                "\n" +
                "The list of medical condition causes of Difficulty climbing stairs (Difficulty climbing stairs) includes:\n" +
                "\n" +
                "Autoimmune thyroid diseases\n" +
                "Brain cancer\n" +
                "Chronic Inflammatory Demyelinating Polyneuropathy\n" +
                "Dermatomyositis\n" +
                "Duchenne Muscular Dystrophy\n" +
                "\n" +
                "Treatment :\n" +
                "\n" +
                "Consult a doctor.";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "climbing");
        res.putExtra("climbing", desc);
        startActivity(res);
    }

    public void result7(View view) {
        String desc = "DIFFICULTY IN WALKING \n" +
                "--------------------\n" +
                "\n" +
                "Difficulty walking: Where ones has a problem with mobilizing on ones feet.\n" +
                "\n" +
                "The following medical conditions are some of the possible causes of Difficulty walking. There are likely to be other possible causes, so ask your doctor about your symptoms. \n" +
                "\n" +
                "Foot injury \n" +
                "Foot fracture \n" +
                "Toe fracture \n" +
                "Ankle fracture \n" +
                "Disc prolapse \n" +
                "Peripheral neuropathy \n" +
                "Peripheral vascular disease \n" +
                "Stroke \n" +
                "Guillain-Barre syndrome \n" +
                "Multiple sclerosis \n" +
                "Cerebral palsy \n" +
                "Transverse myelitis \n" +
                "Spinal stenosis \n" +
                "Spinal cord injury \n" +
                "Motor neurone disease \n" +
                "Poliomyelitis \n" +
                "Osteoarthritis \n" +
                "Obesity \n" +
                "\n" +
                "Treatment :\n" +
                "\n" +
                "Treatment for difficulty walking may include:\n" +
                "\n" +
                "Support while walking:\n" +
                "Use a walker.\n" +
                "Use crutches.\n" +
                "Use a cane.\n" +
                "Wheelchair\n" +
                "Physical therapy";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "walking");
        res.putExtra("walking", desc);
        startActivity(res);
    }


    public void result8(View view) {
        String desc = "FREQUENT URGE FOR URINATE\n" +
                "-------------------------\n" +
                "\n" +
                "Frequent urination means needing to urinate more often than usual. Urgent urination is a sudden, strong urge to urinate, along with discomfort in your bladder.\n" +
                "\n" +
                "A frequent need to urinate at night is called nocturia. Most people can sleep for 6 to 8 hours without having to urinate. \n" +
                "\n" +
                "Causes:\n" +
                "Common causes of these symptoms are:\n" +
                "•Urinary tract infection (UTI)\n" +
                "•Enlarged prostate in middle-aged and older men\n" +
                "•Leakage of urine from the urethra (the tube that carries urine out of your body)\n" +
                "•Swelling and infection of the urethra\n" +
                "•Vaginitis (swelling or discharge of the vulva and vagina) \n" +
                "\n" +
                "Treatment:\n" +
                "Follow the advice of your health care provider to treat the cause of the problem. It may help to write down the times when you urinate and the amount of urine you produce. Bring this record to your visit with the health care provider.\n" +
                "\n" +
                "In some cases, you may have problems controlling urine (incontinence) for a period of time. You may need to take steps to protect your clothing and bedding.\n" +
                "\n" +
                "For nighttime urination, avoid drinking too much fluid before going to bed. Cut down on the amount of liquids you drink that contain alcohol or caffeine. \n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "urinate");
        res.putExtra("urinate", desc);
        startActivity(res);
    }

    public void result9(View view) {
        String desc = "ITCHING AND BURNING IN PELVIC REGION\n" +
                "-------------------------------------\n" +
                "There are several common causes of vaginal itching, burning, and irritation, including:\n" +
                "• Bacterial vaginosis . \n" +
                "• Sexually transmitted disease (STDs). \n" +
                "• Yeast infection  (vaginal candidiasis)\n" +
                "• Menopause. \n" +
                "• Chemical irritants\n" +
                "Treatment:\n" +
                "\n" +
                "Vaginal irritation will often get better on its own. However, if the irritation continues, is severe, or comes back after treatment, call for an appointment with your doctor. The doctor can do a pelvic exam. The doctor will probably also take a sample of the discharge to find the source of the problem.\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "burning");
        res.putExtra("burning", desc);
        startActivity(res);
    }

    public void result10(View view) {
        String desc = "LUMP OR BULDGE \n" +
                "-------------\n" +
                "\n" +
                "\n" +
                "There are 20 conditions associated with lump or bulge (pelvis), lump or bulge (groin), pain or discomfort (pelvis) and pain or discomfort (groin). \n" +
                "\n" +
                "1.Abscess\n" +
                "2.Muscle strain\n" +
                "3.Urinary tract infection (UTI)\n" +
                "4.Kidney stones\n" +
                "5.Legg-Calve-Perthes disease\n" +
                "6.Swollen glands\n" +
                " 7.Bladder cancer\n" +
                "8.Bladder stones\n" +
                "9.Hip (acetabular) labral tear\n" +
                "10.Interstitial cystitis\n" +
                "11.Lumbar spinal stenosis \n" +
                "12.Hidradenitis suppurativa\n" +
                " 13.Small intestine cancer\n" +
                " 14.Cat-scratch disease";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "lump");
        res.putExtra("lump", desc);
        startActivity(res);
    }

    public void result11(View view) {
        String desc = "NUMBNESS OR TINGLING ON PELVIC REGION \n" +
                "-------------------------------------\n" +
                "Causes:\n" +
                "\n" +
                "        Motor vehicle accidents\n" +
                "        Sciatica\n" +
                "        Peripheral vascular disease\n" +
                "        Fracture of pelvic bone with open wound injury\n" +
                "         Femur fracture\n" +
                "Treatments:\n" +
                "\n" +
                "Only your doctor can advise whether any of these treatments are appropriate for your specific medical situation. ";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "numbness");
        res.putExtra("numbness", desc);
        startActivity(res);
    }

    public void result12(View view) {
        String desc = "PELVIC PAIN OR DISOMFORT\n" +
                "----------------------\n" +
                "\n" +
                "Causes:\n" +
                "\n" +
                "Possible causes of pelvic pain in both men and women may include:\n" +
                "\n" +
                "Appendicitis\n" +
                "Bladder disorders\n" +
                "Sexually transmitted diseases\n" +
                "Kidney infection or kidney stones\n" +
                "Intestinal disorders\n" +
                "Nerve conditions\n" +
                "Hernia\n" +
                "Pelvis disorder\n" +
                "Broken pelvis\n" +
                "Psychogenic pain\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "The treatment of pelvic pain varies depending on the cause, how intense the pain is, and how often the pain occurs. Sometimes, pelvic pain is treated with medications, including antibiotics if necessary. If the pain results from a problem with one of the pelvic organs, the treatment may involve surgery or other procedures. A doctor can provide more information about various treatments for pelvic pain."
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "ppain");
        res.putExtra("ppain", desc);
        startActivity(res);
    }

    public void result13(View view) {
        String desc = "SWELLING IN PELVIC REGION\n" +
                "-------------------------\n" +
                "\n" +
                "The following medical conditions are some of the possible causes of Pelvis swelling. There are likely to be other possible causes, so ask your doctor about your symptoms. \n" +
                "\n" +
                "1.Motor vehicle accidents\n" +
                "2.Fracture of pelvic bone with open wound injury\n" +
                "3.Femur fracture\n" +
                "\n" +
                "Treatment:\n" +
                "\n" +
                "Only your doctor can advise whether any of these treatments are appropriate for your specific medical situation.\n" +
                "\n";
        Intent res = new Intent(this, result.class);
        res.putExtra("key", "swelling");
        res.putExtra("swelling", desc);
        startActivity(res);
    }

}